# Laptop integration checkpoint — 2026-10-01

## Current disposition

The cloud release candidate is now published as draft PR98. This checkpoint makes
no claim that it has been integrated into the laptop, merged, deployed, or is the
revision currently serving. CompSet remains laptop-owned and separate from this
Yellow release.

The source records distinguish these states:

| State | Evidence | Classification |
|---|---|---|
| Laptop committed basis | `E:\YellowWorkspace\Worktrees\git-live-order611-source-v2`, branch `codex/live-order611-source-v2`, reported HEAD `e06e400a57485cc10a8a35c21dcb1e01b5a667d1` | Reported physical laptop state. Checkout itself is not accessible here; refresh HEAD/status before reconciliation. |
| Earlier laptop dirty snapshot | 50 modified tracked paths and 215 untracked paths; broader 643–734 feature work and protected app/operator/workspaces were reported | Snapshot is not a current inventory. Current exact path list/hashes remain laptop-owned; preserve all dirty features. |
| Published laptop branch | `codex/live-order611-source-v2` at `d708ff29e2e44df74a5c1a12e58a8cf656b14c8d`, direct descendant of e06 | Published committed source. PR97 is open against `main`; it is not merged. |
| Current release candidate | `phase-7/release-local-gates-20261001` at `f610a9264840cbbf8d4ea05b29852889e0115e6f`, tree `f810a9d36276a8891b55209fcc5d3d22a9d19451` | Published PR98 head; base d708 is unchanged and source is frozen. |
| Release main | `3503b0c01f336637d2583963c17b792f6ad59efe` | Current recorded main boundary. |
| Pull requests | [PR98](https://github.com/dcpnode-maker/yellow/pull/98), current head `f610a92`; PR97 remains open against `main` | PR98 is published but not merged. No laptop integration is implied. |
| Official CI | Run `36824204133` completed RED: five required jobs green, database failed at native fiscal release containment | No release acceptance; resolve under reviewed successor order and pass full CI. |
| Local proof | Default standing 2,520 passed / 1,579 explicit DB environment skips / 0 failed / 44,979 assertions in 62.84s; canonical 11/11 | Local source proof; not laptop receiving-tree or live-serving proof. |
| Reviewed successors | ARM image-index repair `20c9ee1` and catalogue successor `808064d`: 9/0/37, 5/0/159, seven authority denials, canonical 11/11 unchanged | Bounded reviewed source proofs. |
| Synthetic merge check | Earlier synthetic merge `e766090` had tree `cfde499`, equal to then-published tree `937912c` | Historical tree-equivalence receipt only; it does not establish integration of current `932969a`. |
| Serving image | No immutable current serving revision/readiness receipt supplied | Laptop/live serving identity remains unknown. |
| Laptop UI/type report | Laptop reports 42 passed / 0 failed / 626 assertions across 11 files, full typecheck exit 0, and restored local execution | Laptop-reported only; exact receiving tree and live-serving identity remain unverified here. |

The laptop is the main source authority, receiving, and final-integration controller; cloud work is a bounded worker lane. The currently published exact Git commit is fetchable, but there is no evidence it has been received by the physical laptop. The laptop instruction is to continue under quota monitoring
and stop/checkpoint at no more than 1% PLAN remaining. No cloud usage reader or hard
cap is available; no emergency-credit fallback. No session, secrets, global desktop
settings, or tunnel are required for this handoff.

Mobile/tablet/laptop, Android/iOS, and enterprise hierarchy/package-registration
requirements remain in the laptop's separate design lane. This cloud release did
not add schema or package implementation for that lane.
Laptop separately reports Node `33.268s` installation and Android JS validation;
these belong to that separate mobile lane and are not cloud release acceptance.

## Current release proof and remaining blockers

Earlier PR98 head `a0fecd9` has a 1,130-byte static entry, 372,851-byte maximum
JavaScript chunk, and 201,002-byte initial gzip transfer. That source-bound receipt
and the old `published-release-a0fecd98-20261001.zip` remain historical. Git
verification in `frontend-current-source-binding.json` confirms all frontend,
generated public assets, root package metadata, and Bun lock bytes are identical
between a0fecd9 and a00ca3f; the current exact delta has no frontend/build paths. This binds unchanged bytes, not a newly
generated or exported current bundle; the final bundle remains unexported.

Official CI run `36827406928` is pending on exact f610 source: quality, local-review, Windows and container-smoke are green; ARM64 and database are in progress. Do not infer acceptance; all-required CI is not complete. Run `36824204133` for prior source 932969 is historical RED (five jobs green; database containment failed), and remains preserved as historical evidence. Earlier
run `36817617539` had a database RED caused by its mutable-relation estimate
matching a constraint instead of normalized `pg_class`; the focused repair uses
actual `ANALYZE` proof. Preserve the raw earlier receipts. Current default standing
is 2,520 passed / 1,579 explicit DB environment skips / 0 failed / 44,979 assertions
in 62.84s; canonical 11/11, independent negative-authorization and CRLF proofs
pass. The a00 strict-flag CI was the first 99/100 strict run and had dependent Q2 12 plus PostgreSQL 16/current 18 constraints; it remains a historical failed receipt. The successor requires exact CI database/address validation, non-55503 port, PostgreSQL server 18, and native client 16 unchanged. These are separate bounded proofs and do not override the official database RED.

Exact Git comparison shows 135 paths changed from laptop basis e06 and 7 since 932969. There are 28 paths since 937912; the earlier 18-since-937 count was incorrect (937912 to 932969 is 23). Since 932969, the paths are `DECISIONS.log`, `handoff/LEDGER.md`, `handoff/orders/RELEASE-20261001-containment-frontier.md`, `handoff/questions/RELEASE-20261001-containment-frontier.md`, `handoff/reviews/RELEASE-20261001-containment-frontier.md`, `tests/india-gst-accommodation-final-component-tax-recording.integration.test.ts`, and `tests/native-fiscal-release-containment.integration.test.ts`.
The refreshed `successor-status-for-laptop.json` records current SHA-256 hashes for
all receiving paths; use it rather than stale earlier receipts.

The cloud branch contains exactly 100 migrations, byte-identical to e06, and no
0101 migration file. In actual retained `yellow_dev`, applied and maximum migration
are both 100 with zero rows >=101; version 100 checksum is
`f70844b2c8205c286f7f552dd1f8a4a2023645f70dcd00dbdacc7c777b0415d4`. The laptop's
earlier 0101 collision was unconfirmed, not a fact. Its reported
`0101_linked_group_runtime_commands.sql` is an unpromoted local input; the laptop
controller should inspect its exact source, migration ledger, and serving image.
No renumbering or combination is authorized. Root owns refreshed
`cloud-migration-inventory.json`; use its current hashes.

## Known path overlap and reconciliation rules

The actual laptop manifest is not present, so a complete overlap count would be
invented. Compare path sets only after receiving a contemporaneous `git status`
and the current changed-path list from that exact checkout. Normalize separators,
retain case-sensitive Git paths, and classify each path as: laptop modified,
laptop untracked, protected, cloud candidate, or generated build output. For every
intersection, compare the laptop blob/current file hash with the pinned cloud
candidate hash and review the changed hunks. Do not use a whole-branch merge,
blanket patch, cherry-pick, reset, checkout, or bulk commit against the dirty tree.

Known high-risk intersections requiring exact hunk reconciliation:

| Paths | Cloud candidate relation | Required handling |
|---|---|---|
| `src/app.ts`, `src/http/operator.ts` | Protected wiring occurs in reviewed composition/CRS delivery; exact candidate bytes are listed in their manifests | Immediate request: current laptop hashes and changed hunks; retain laptop routing/authority behavior and reconcile only these exact files. |
| `frontend/yellow/src/App.tsx`, `frontend/yellow/src/main.tsx`, workspace/navigation boundaries | Protected laptop source; release bundle configuration and generated public artifacts are separate cloud changes | Obtain current hashes/hunks for protected app/navigation boundaries and entry build receipt. Compare emitted artifact manifest before any asset reconciliation. |
| `public/yellow-next/**` | Release order admits exact generated asset paths/hashes and removals | Treat as generated output. Admit only exact current-build manifest paths after the laptop entry point and source hashes are known; preserve any distinct laptop build. |
| `.codex/config.toml` and project MCP configuration tests | Published candidate has valid empty project `[mcp_servers]` template under the accepted policy | Request only safe preimage/current config hashes and sanitized failing-key/type inventory. Never export credential values, old configuration secrets, or start removed servers. |
| `setup.sh`, `setup.ps1`, catalogue/referee tests, fixture tests, `DECISIONS.log`, `handoff/LEDGER.md` | Reviewed catalogue and test-only successors are separate deliveries; append-only governance must be reconciled | Keep exact manifest order and hashes. Resolve existing laptop edits first; append governance records rather than replacing the files. |
| CRM/task/work-order paths | Next task-distribution slice is not defined by the current reviewed source set | Request only the paths enumerated in `LAPTOP_REQUEST_YELLOW_SOURCE.md`; do not infer integration from generic task storage or cloud CRM deliveries. |

Root maintains refreshed `successor-status-for-laptop.json` and
`cloud-migration-inventory.json`; use their current versions for receiving-path
hashes. Do not use the prior 122/14 counts. These deltas do not authorize replacing
other dirty laptop work. Preserve all existing dirty features and review protected
app/operator changes and generated assets separately.

## Safe recovery from GitHub to the laptop

The laptop controller asked that all recoverable work also be available on GitHub and the laptop. Fetch the exact published commit `932969aa5304b4fea9bfa8c64b43085023cd4d89` directly from PR98/GitHub into a new isolated checkpoint/worktree; verify the fetched commit SHA and tree `b26dfa1bb8eabfd77f3792266391d15a0e440b6e`. Then copy only the allowlisted files from the current root-owned safe artifact bundle into a separate receiving checkpoint and verify every file against the current `successor-status-for-laptop.json` hashes. Do not apply the bundle wholesale to the dirty controller checkout, cherry-pick into it, or report files as copied until the laptop confirms receiving hashes. Preserve all dirty and untracked laptop work. Current safe bundle is a source backup only; it must retain that label; it is not a fully accepted release archive.

## Deterministic integration sequence

1. **Refresh source identity.** From the exact laptop checkout, provide current
   `HEAD`, branch, timestamped `git status --short`, and only the relevant protected
   file hashes plus changed hunks. Confirm whether HEAD is still e06; do not infer
   it from the published d708 ref.
2. **Refresh artifact identity.** Provide the current frontend entry/build receipt,
   exact emitted file/hash/size manifest, sanitized MCP failing-key/type inventory,
   and the project-level configuration contract. Keep credentials and session data
   out of the exchange.
3. **Reconcile paths.** Compare each relevant laptop path to the exact candidate
   artifact manifest. Record `unchanged`, `same change`, `disjoint change`, or
   `conflict` per path. Resolve protected app/operator/workspace conflicts by
   explicit hunks. Keep generated public assets tied to a build receipt.
4. **Freeze the receiving basis.** Produce a reviewable checkpoint from the
   reconciled laptop source with exact path/hash manifest and a finite patch. Keep
   the laptop's unrelated modified and untracked files untouched. No commit is
   implied by preparing this checkpoint.
5. **Prove only changed behavior.** Run 36827406928 is pending with four required jobs green and ARM64/database in progress; prior run 36824204133 remains historical RED for 932969. The parent reports full series 17/0/1,318; Q2 128/0/68; historical 89→90 5/0/169; 11 admission denials and 99/101 negative cases; canonical 11/11; types 207; default standing 2,520 passed / 1,579 explicit DB skips / 0 failed / 44,979 assertions in 62.84s. Root local receipts also include containment/readiness 41/0/404; compatibility 10 files 89/0/2397; canonical11/11; negative99/101 rejects; types207; default 2,520/1,580 explicit DB skips/0/44,979 in64.98s. These are bounded local receipts, not official CI acceptance. The strict database flag now requires the exact CI database address, rejects port 55503, requires server major 18, and preserves native client 16. Generate the final bundle only after all required CI is accepted.
6. **Review and integrate.** PR98 is already published on
   `phase-7/release-local-gates-20261001`; current head is `f610a92`, tree
   `f810a9d`. The laptop is the receiving controller: compare exact candidate paths
   and hashes with its dirty checkout, review the hunks, and make the final
   integration decision locally. Do not replace unrelated dirty files. PR97 remains
   open against `main`.
7. **Verify serving separately.** Capture timestamped immutable source revision,
   OCI/image digest, deployment identity, and current readiness response from the
   serving control plane. Source acceptance or historical `/health` evidence does
   not prove the running revision. A separate database/session pass does not imply
   all PMS workflows are complete.

## Finite acceptance by artifact

| Artifact | Accepted when |
|---|---|
| Current laptop subset | Exact checkout identity, hashes and changed hunks for paths in the refreshed `successor-status-for-laptop.json`, plus protected app/operator/workspace and current MCP preimage evidence; unrelated dirty files preserved. |
| Reviewed cloud source | Current head `f610a92`, tree `f810a9d`, and exact path hashes match the refreshed status manifest; no unreviewed laptop bytes are replaced; laptop controller reviews the receiving tree. |
| MCP policy | Project config matches the approved empty-server contract; unchanged tests reject malformed, duplicate and control-character keys as specified; no credential value is disclosed. |
| Frontend bundle | After final required CI passes, generate from current accepted source and record exact entry/chunk hashes and sizes, strict budgets, and asset admissions. The old a0fecd9 build/archive remain historical. |
| Browser proof | Laptop UI report is 42/0/626 over 11 files with typecheck exit 0, reported by laptop; independently bind it to exact receiving hashes before treating as integration proof. Existing required browser scenarios retain their deadlines, assertions, cleanup and zero-write/replay controls. |
| Release gates | All required CI jobs, including database acceptance, pass on frozen current source; retain canonical 11/11 and bounded independent proofs. A subsystem proof cannot substitute for this gate. |
| PR/publication | PR98 head/tree and exact changes are reviewed; all required CI on a successor is green; laptop controller accepts exact local integration. Merge/deploy remain separate actions. |
| Serving | Immutable currently serving source revision and image digest are recorded alongside fresh readiness evidence. Historical or absent telemetry remains unknown. |

## Exact next laptop request

Please provide only this bounded current subset: (1) exact receiving hashes and
changed hunks listed in the refreshed `successor-status-for-laptop.json`; (2) hashes
and hunks for protected app/operator/ReservationWorkspace plus the safe MCP config
preimage; (3) current laptop HEAD, branch and status; if retained, the unpromoted
0101 input's exact hash and applied `schema_migration` row; and (4) immutable serving
image/source revision and timestamped readiness identity. Use the refreshed
`cloud-migration-inventory.json` for migration hashes. The earlier 0101 collision
was unconfirmed. Laptop retains final integration authority. No full dirty checkout, secrets, raw sessions, desktop-wide settings, tunnels, guest records, or CompSet files are requested. Do not send an app URL unless an actual private live endpoint and immutable serving identity are verified; no app Tunnel ID, Access application, or current hostname is known. See `CLOUDFLARE_SUPPORTED_HOSTING.md` for the docs-only hosting assessment.

## Basis records

- `../LAPTOP_REQUEST_YELLOW_SOURCE.md` — bounded source request.
- `../delivery/reconciliation/PMS-CRS-20260930-reconciliation.md` — source, PR and
  runtime distinctions, plus preserved CRS comparison.
- `../delivery/reviewed-composition/manifest.json` — e06-based 40-path candidate.
- `../delivery/current100-catalogue/manifest.json` and
  `../delivery/inherited-fixtures/manifest.json` — separate successors.
- `../../yellow-release/handoff/orders/RELEASE-20261001-local-gates.md` and its
  question — bounded browser/frontend/MCP gates and exact artifact admissions.
- `frontend-current-source-binding.json` — Git-verified unchanged frontend inputs
  and generated bytes since a0fecd9; not a new build/export receipt.
