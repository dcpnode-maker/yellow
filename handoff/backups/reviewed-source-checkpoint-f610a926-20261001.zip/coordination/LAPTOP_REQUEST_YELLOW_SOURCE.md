# Narrow Yellow integration/task source request

Cloud accepted source against e06 is composition6b0be81, catalogue627905f and
test-only fixture successor51d3f47. Manifests/patches/proofs are in delivery/.
Protected app/operator wiring is separate. No laptop integration is claimed.

For the next operational CRM assignment/follow-through slice, supply only:

- Current src/contexts/housekeeping/tasks.ts, src/contexts/crm/parties.ts,
  src/contexts/stay-operations/pickup-task-dispatch.ts and pickup-task-automation.ts,
  if changed from committed basis; exact hashes or an explicit unchanged attestation.
- Existing published task assignment/ack/start/complete/cancel command types,
  staff-user-to-party/department grant contract and their HTTP route registration.
- Exact changed/untracked operational task inbox, today/shift and guest-request
  module/test paths and the bounded subset covering assignment/follow-through.
  No need to export every untracked module or the desktop/session.
- Saved command/result summaries for these exact modules; due/SLA/escalation and
  replay/tenant/property/staff authority proof where already implemented.

For release reconciliation, supply current protected frontend App.tsx/main.tsx,
workspace/navigation boundaries and entry build receipt before any cloud bundle
split: remote entry215302 exceeds strict200000; the dirty laptop may differ.
Do not raise the budget or replace laptop source to match the remote snapshot.
For tracked MCP configuration policy, share the exact sanitized failing-key/type
inventory and intended project-level configuration contract, never credential
values. Cloud will preserve the strict security test while reconciling scope.

For Hotel/STR/Both implementation, the needed next subset is current registration,
tenant/property-mode, onboarding, server-authorized property-grant and ribbon
boundaries. Views share one PMS inventory and switching never grants access.
Preserve owner/co-host consent and multiple Airbnb account/listing mappings.

Also provide timestamped source/OCI revision and redacted readiness evidence.
Historical health200/ready503 and public case studies do not prove a current
serving revision or Lighthouse roster. The separate Lighthouse request remains.

No passwords, environment/credential values, cookies, raw sessions, real guest
records or provider transport are requested. CompSet remains laptop-owned.
