# Yellow source reconciliation for operational CRM task distribution — 2026-09-30

**As-of window:** 2026-09-30 18:18–18:24 UTC
**Audit basis:** `e06e400a57485cc10a8a35c21dcb1e01b5a667d1`
**Scope:** Yellow only. No marketing CRM and no CompSet. Read-only Git/GitHub/runtime-evidence review plus this report.

## Decision

Three different source states are present:

| State | Exact evidence | What it establishes |
|---|---|---|
| Release main | GitHub `refs/heads/main` and `/workspace/yellow` both resolve to `3503b0c01f336637d2583963c17b792f6ad59efe`; PR91 is merged at that SHA. | The last verified consolidated release source. Its project status says main is the sole release branch and records no connected cloud serving target. That status text was last substantively updated earlier than the September 23 laptop promotion, so it is a source/release record, not current runtime telemetry. |
| Laptop committed basis | This audit checkout is at `e06e400a57485cc10a8a35c21dcb1e01b5a667d1`. The separate `/workspace/yellow-pms` CRS candidate builds on e06 at `fbc5f00b961fd202bb95bc70b450486fc8d0dd25`. GitHub compare reports `main...e06` as `diverged`, 35 commits ahead and 1,631 behind. | A committed source line exists beyond main, but it is not integrated into main. The local audit clone is shallow and has no local common ancestor for these two objects; the GitHub compare result is the authoritative ancestry evidence used here. |
| Published laptop-source ref | `refs/heads/codex/live-order611-source-v2` resolves to `d708ff29e2e44df74a5c1a12e58a8cf656b14c8d`; its parent is exactly `e06e400…`. `/workspace/yellow-live` is clean at this commit. | The committed `e06` basis is pushed and included in the published branch. This exact branch is PR97’s open head, not a main merge. It does not establish the completeness or contents of the laptop’s separately reported uncommitted working tree. |

The live laptop handoff reports 556 preserved entries, including 50 modified tracked
domain-inventory paths and 215 untracked source/test/frontend/migration paths. That is
reported laptop state only: no direct laptop checkout, path contents, hashes, or
screenshots were supplied. It must stay classified as **uncommitted reported work**;
no conclusion about the presence or absence of any one file can be made from a remote
tree listing. Further local commits beyond the exact `e06` basis are **unknown**:
the published branch includes `e06`, but there is no contemporaneous laptop ref
snapshot to compare. Do not call any such commits unpushed or pushed without that
snapshot.

## Source, PR, checks, and serving evidence

All GitHub queries and `git ls-remote` reads in this section were captured between
18:18 and 18:24 UTC on September 30. The repo is public and its default branch is
`main`.

| Evidence | Observation | Classification |
|---|---|---|
| `git ls-remote --heads origin main codex/live-order611-source-v2` | `main=3503b0c…`; `codex/live-order611-source-v2=d708ff2…`. | Current remote ref observation at 18:18 UTC. |
| GitHub compare [`main...e06e400`](https://github.com/dcpnode-maker/yellow/compare/3503b0c01f336637d2583963c17b792f6ad59efe...e06e400a57485cc10a8a35c21dcb1e01b5a667d1) | `diverged`; head e06 is 35 commits ahead and 1,631 behind main. The 35 head commits include the four final source commits visible in the e06 lineage (orders 639–642) plus earlier ancestry. | Exact public ancestry comparison. The local shallow clone’s `rev-list` count is not used as a substitute. |
| GitHub compare [`e06...d708`](https://github.com/dcpnode-maker/yellow/compare/e06e400a57485cc10a8a35c21dcb1e01b5a667d1...d708ff29e2e44df74a5c1a12e58a8cf656b14c8d); commit [`d708ff2`](https://github.com/dcpnode-maker/yellow/commit/d708ff29e2e44df74a5c1a12e58a8cf656b14c8d) | One commit after e06: `[codex] repair PR97 browser proofs and current migration gates`. Parent is the exact e06 SHA. | The committed basis is on the published branch. |
| [PR91](https://github.com/dcpnode-maker/yellow/pull/91) | Closed/merged 2026-09-06 at `3503b0c…`. | Confirms the release main source boundary. |
| [PR97](https://github.com/dcpnode-maker/yellow/pull/97) | Open, non-draft, updated 2026-09-29; base `main` at `3503b0c…`; head `codex/live-order611-source-v2` at `d708ff2…`; 36 commits, 2,426 changed files, 537,848 additions and 3,452 deletions; `mergeable=false`, state `dirty`. | The published laptop line has not integrated into main. PR97’s title/body describes the Order635 PostgreSQL18 housekeeping fix, but its accumulated head covers the whole divergent source lineage. It is not a narrow Order611 PR. |
| Laptop promotion review [`Review 611`](../handoff/reviews/611-public-promotion-evidence.md) | Dated September 23; records 8 focused passes / 67 assertions, typecheck, 203-file boundary scan, build, and local/public health 200. It identifies a temporary source worktree but no immutable OCI digest or serving Git revision. | Historical promotion evidence, not proof of what is serving now. |
| Reported runtime state in the founder handoff | Last reported `/health` 200, `/ready` 503, missing revision/runtime-serving-role inheritance; no current endpoint or response body was supplied. | **Reported, not independently verified.** Stale serving revision is a concern, not a proven current fact. No `/ready` request, OCI control-plane query, credential/environment inspection, or current endpoint check was performed in this audit. |

The current main status record says no cloud host, ingress, or serving URL is connected
([`docs/PROJECT-STATUS.md` at main](https://github.com/dcpnode-maker/yellow/blob/3503b0c01f336637d2583963c17b792f6ad59efe/docs/PROJECT-STATUS.md), “Source and release truth”). Review 611 records a later laptop promotion, so the two statements describe different evidence dates and source lines. Neither establishes current serving identity. The handoff’s reported 503 is later but lacks an endpoint, timestamped response, image digest, and build revision; it cannot close that gap.

PR97 also creates a scope/provenance mismatch: its public title/body is about Order635,
while its head is the `live-order611-source-v2` branch containing the entire 35-commit
divergent line and thousands of changed files. The branch’s last commit message
describes repair of the accumulated PR, not a new runtime promotion. Its successful
CodeQL checks do not change that PR scope or establish the runtime image source.

## Separate PMS/CRS candidate already reviewed

The staff CRS search is a separate, clean local candidate at
`/workspace/yellow-pms`, branch `phase-7/pms-crs-staff-offer-search-20260930`, commit
`fbc5f00b961fd202bb95bc70b450486fc8d0dd25`, based on the same e06 SHA. Its independent
review is [`handoff/reviews/PMS-CRS-20260930-staff-offer-search.md`](/workspace/yellow-pms/handoff/reviews/PMS-CRS-20260930-staff-offer-search.md).
That review approves only the frozen staff multi-property offer-search behavior. It
does not approve laptop integration, release publication, merge, or deployment.

The review records the following exact candidate hashes:

```text
89cd679498fd3aa0f2271c85e5ef79c1e0d9af847355bed2fcc533944aeefcf1  src/http/crs-search.ts
2f7c545585189f206276a90163d60133c8f5c98acf4a9a149876da83ee04d590  src/app.ts
1a703a8b40e3e6a45573b7ba9ea48e51d85103f7b63eef9b4ec4798710093dc9  src/http/operator.ts
252340e6a09864174644f4a4b8ff61a3f75b38b3f2024931f768c8a043baefe8  tests/pms-crs-20260930-staff-search.test.ts
68e71a4c2758ace6060ef2db0c5fa3d0046be33b23445c30260c5f5f027facaf  tests/pms-crs-20260930-staff-search.http.test.ts
e48d6906da077022c9aa619ec28657dd372e6581c49ae3cec0aea7af2170d6c7  tests/pms-crs-20260930-staff-search.integration.test.ts
5455c41027efe39b9dc930aba2effc7f0d53ac415b76bedc7de69fb325acf201  docs/CONTRACTS.md
```

Reviewer-executed candidate proof: unit/HTTP 27 passed, 0 failed (163 assertions);
real-PostgreSQL integration 6 passed, 0 failed (66 assertions); negative runtime,
deploy-role, owner-role, and mismatched-target modes failed closed as required;
calendar 4/0 (16); typecheck, 205-file import boundaries, and `git diff --check`
passed. The candidate retains two inherited release blockers: `license-check` rejects
`tslib@2.8.1` declared as `0BSD`, and the legacy offers suite reports 1 pass / 5 fail
on both this candidate and pristine tracked e06. The unmodified canonical database
referee passed 11/11 on an isolated target, with migrations 1–100 and 130 public
tables. The reviewer explicitly leaves release gates red. These figures are quoted
from that review; this reconciliation did not rerun them.

This candidate is useful secondary PMS/CRS evidence, but it is not the current primary
task. It demonstrates a scoped query and grant-checking implementation. It does not
establish end-to-end reservation booking, CRS distribution sync, or current laptop
route wiring. Only two candidate wiring files overlap the reported protected modified
laptop files: `src/app.ts` and `src/http/operator.ts`. The helper
`src/http/crs-search.ts` is new and unprotected. These exact files need reconciliation,
not wholesale replacement.

## Existing task foundation in committed e06

The committed source has a generic `public.task` table with `kind`, `status`, subject,
assignee, department, due instant, priority, payload, and a tenant/property board index
([`migrations/0001_init.sql`](../migrations/0001_init.sql), lines 202–221). That is a
storage primitive; it does not by itself establish a general staff dispatch product.
The domain model still marks assignment, dependencies, evidence, comments/attachments,
and SLA as a kernel target and says legal states must be decided before implementation
([`docs/DOMAIN-MODEL-V1.md`](../docs/DOMAIN-MODEL-V1.md), lines 180–187). The same
model says asset registry/work-order separation is a future target extension (lines
426–430).

There are bounded existing work lanes which must be reused rather than duplicated:

- Housekeeping has its own service and `start → complete → verify` lifecycle, task
  board/detail, room-condition evidence, and distinct work/inspection authority
  ([`src/contexts/housekeeping/tasks.ts`](../src/contexts/housekeeping/tasks.ts),
  [`PROJECT-STATUS`](../docs/PROJECT-STATUS.md), Orders 201/217/635/636).
- Departure-service coordination creates canonical `guest_request` tasks, dispatches
  to a configured role, records work, and has a separately confirmed escalation
  queue. Its state machine is deliberately bounded
  ([`migrations/0099_governed_departure_service_coordination.sql`](../migrations/0099_governed_departure_service_coordination.sql),
  [`docs/STATE-MACHINES.md`](../docs/STATE-MACHINES.md), lines 386–400).
- Arrival pickup is another specialized task flow. Existing Today, pickup, departure,
  and housekeeping surfaces are outside the new distribution UI request.

The source inventory found no general task-distribution context under
`src/contexts/` and no separate work-order context in this e06 tree. This is a
source-tree finding for committed e06 only; it cannot determine whether the reported
dirty laptop tree adds one.

## CRM-first feature and proof sequence

The founder’s latest correction makes operational task distribution the primary
integration target. “CRM” here means hotel work coordination: current tasks/work
orders/guest requests, staff and department queues, due/SLA/escalation, acknowledgement,
status/completion, and shift views. It does not authorize marketing CRM, campaigns,
lead scoring, or duplicate housekeeping/pickup/Today/departure modules. The reported
laptop path inventory is not locally available; only groups and claims supplied by
the founder are listed below.

### Active bounded CRM order

The coordinator has since opened
[`CRM-20260930-departure-dispatch-queue.md`](/workspace/yellow-crm/handoff/orders/CRM-20260930-departure-dispatch-queue.md)
on a separate branch at the same e06 basis. It narrows urgent CRM work to one current
defect: in the existing departure guest-request property queue, up to 100 completed
rows can hide later unfinished work. The authorized change sorts `open`, `assigned`,
and `in_progress` requests ahead of completed outcomes, then keeps due-time/ID order;
it uses existing governed commands, retains completion/history and receipts, and adds
no lifecycle, schema, route, UI, or general SLA policy. The new real-PostgreSQL backlog
proof remains pending. Coordinator-reported existing proof is 12 real-PostgreSQL
tests / 127 assertions; those tests are not the new backlog acceptance.

This CRM-order update arrived after the 18:18–18:24 GitHub evidence window; it does not
change any captured source ref, PR state, review, or check result.

Thus the next CRM step is this bounded active-first ordering proof, not a new generic
staff inbox or a duplicate housekeeping/pickup/departure feature. The committed domain
model still marks broader assignment, SLA, and work-order semantics as targets, so
those remain deferred. After urgent CRM closure, Hotel/STR/Both property-registration
and ribbon design is additive and limited to current boundaries. It does not add PMS
entities or treat an owner statement as a trust ledger. No vendor study is included.

| Order | Feature group and dependencies | Executable acceptance before the next group |
|---|---|---|
| 0 | **Reconcile exact source and serving identity.** Use the coordinator’s existing status/ref/runtime request. For the CRM patch, compare only the actual departure-queue source and test hunks against e06/d708; do not inspect or replace existing pickup/Today/departure/housekeeping modules outside the active order’s scope. | Bind the exact CRM source/test hashes to the laptop’s status/ref output already requested. Any serving claim still requires an OCI image digest, immutable source-revision label, and timestamped redacted `/ready` body with matching build revision; no such evidence is currently available. |
| 1 | **Bounded departure-dispatch ordering fix (active order).** Depend on the existing canonical guest-request task, property queue, status, due/ID ordering, and governed propose/confirm/assign/start/complete commands. Keep the change within the current property-mode ordering; do not invent a generic task lifecycle, department policy, or SLA. | First reproduce 100 older completed rows hiding a later open request on the unchanged baseline. On exact candidate, prove unfinished `open/assigned/in_progress` rows sort first with due/ID ties; completed outcomes remain when slots permit; reservation history chronology and completion/replay receipts are unchanged. Real PostgreSQL must use `yellow_runtime`, transaction-local `app_role`, same guarded deploy/runtime target, signed route, tenant/property/scope/revocation denials, and unchanged task/request/fact/outbox/idempotency/occupancy/condition/financial fingerprints on reads. New backlog proof is still pending. |
| 2 | **General current task/work-order/guest-request reads and queue model (deferred).** Depend on the active departure-queue fix and an explicit source-defined contract. Add only the missing shared distribution projection if the laptop source actually has one; do not create duplicate housekeeping, arrival-pickup, departure, Today, or reservation features. | On exact source, real PostgreSQL two-tenant/property/role proof must cover RLS, department/assignee filters, pagination, ordering, no foreign-task disclosure, unchanged task/fact/outbox/occupancy/financial fingerprints, and `security_invoker=true` on any introduced view. Verify specialized queues remain source-authoritative. |
| 3 | **General acknowledge, route, status/completion, due/SLA/escalation, and shift views (deferred).** Depend on a source-defined state/version contract and department policy. Keep housekeeping execution/inspection, guest-request proposal, and departure escalation in their existing governed commands. If laptop source supplies no SLA rules/states, record that policy dependency before implementation. | Real-PG tests cover every defined legal/illegal transition, expected-version conflict, same-key replay, unknown-result recovery, race handling, role/tenant/property/department denial, and same-transaction audit/outbox. No task-only action may change occupancy, housekeeping condition/readiness, or financial records. Mount actual role/department views at desktop/tablet/phone widths and compare state with server receipts. |
| 4 | **Link existing operations only where needed.** After the active queue proof, link current front-desk guest requests and other existing workflows by stable task ID. Housekeeping, pickup, Today, departure, reservation, and guest surfaces stay in their canonical modules; do not duplicate their screens or transitions. | Each linked workflow has one source task/fact, route-level authorization, exact version/replay behavior, and no read-side effects. If a linked room move or sellability action touches a room/night claim, prove competing PostgreSQL writes are arbitrated by the canonical occupancy command. |
| 5 | **Deferred CRS and release gates.** Reconcile the separate reviewed CRS search candidate only after the urgent CRM queue fix and only against exact current wiring. | Repeat CRS unit/HTTP and real-PG proof on the exact integration SHA; exact-head CI/CodeQL, current type/boundary/license/migration/schema/referee gates, tenant isolation, and browser receipts must name the same SHA. Existing 0BSD license and legacy-offers failures remain blockers. Only a separately authorized release with matching OCI digest, build revision, and `/ready` frontier supports a serving claim. |

Project constraints behind these gates are explicit in [`PROJECT.md`](../PROJECT.md):
PostgreSQL owns sellability; `record_occupancy()`/`release_occupancy()` are the only
occupancy writers; insert-only financial facts are never edited; tenant queries set
transaction-local context; journals balance; property timezone owns business date;
and observable state changes write outbox rows in the same transaction. Orders609 and
610 provide the existing UI-level lifecycle contract and viewport proof requirements
([Order609](../handoff/orders/609-reservation-lifecycle-create-edit-surface.md),
[Order610](../handoff/orders/610-reservation-cancel-reinstate-no-show-surface.md)).
The 9/23 Order611 review is read-only UI/workflow evidence and expressly does not claim
whole-PMS completion or final demo acceptance.

## Exact next laptop evidence request

The coordinator’s existing request covers status/ref and serving evidence. The active
CRM order already asks for exact current domain-file hash/change status and queue/test
excerpts, so this audit adds no broader laptop request. The needed CRM-specific subset
is precisely:

- `src/contexts/stay-operations/departure-service-coordination.ts`: whole-file
  SHA-256 and the `#requests` property-mode ordering hunk from the laptop’s actual
  current checkout.
- The relevant existing queue/history fixture excerpts and full-file SHA-256 values
  from `tests/departure-service-contract.test.ts` and
  `tests/departure-service-http.test.ts`, plus the path/hash of the laptop-only backlog
  integration test if present.
- One sentence confirming whether the queue uses existing canonical commands and
  retains completion/history/receipts. Do not resend pickup, Today, general HK,
  departure, reservation, generic task/SLA design, or CRS source. The new backlog proof
  result remains pending; no broad laptop export is requested.

## Limits and audit trail

- This audit inspected Git objects, local worktree status, public GitHub refs/PR/checks,
  committed orders/reviews, and the founder-supplied handoff. It did not inspect the
  laptop, private env/credentials, a current serving endpoint, OCI control plane,
  production database, or customer data.
- `d708ff2` existing CodeQL success is not application CI, merge, or runtime proof.
- Order611’s 9/23 public health receipt is historical and does not bind image to SHA.
- `/ready 503` and stale serving revision are reported only; neither was observed in
  this run. Current serving status is unknown.
- Laptop dirty/untracked path contents and commits beyond e06 are unknown. The public
  remote tree cannot adjudicate them.
- No application code, tests, migration, deployment, branch/tag ref, PR, or database
  was changed. The permitted read-only fetch updated only local `FETCH_HEAD`.

**Evidence inventory:** 3 named source refs; 1 public ancestry comparison; 2 PR
records (#91 merged, #97 open); 2 PR97 review records; 4 exact-head CodeQL checks; 1
historical Order611 promotion review; 1 independent CRS review. No runtime endpoint
response or OCI digest was available.
